import java.util.Scanner;
import java.util.Random;

public class RockPaperScissorsGame {

    public static void main(String[] args) {
       System.out.println("Let's Start.");
        Scanner Scan = new Scanner(System.in);
        Random Rand = new Random ();

        int computerScore = 0;
        int yourScore = 0;
        int counter = 0;
        int round = 1;

        String a ="rock";
        String b ="paper";
        String c ="scissors";

        System.out.println("The first player who reaches 5 points wins. Okay?");
        System.out.println("Your score = 0  My score = 0");
        System.out.println("Round 1 ");

        while(counter == 0) {
            int computerChoice = 1 + Rand.nextInt(3);
            System.out.println("Rock, paper or scissors?");
            String value = Scan.nextLine();
            String lvalue = value.toLowerCase();
            if (lvalue.equals(a)) {

                if (computerChoice == 2){
                    System.out.println("My answer was scissors. Rock breaks scissors. You won. ");
                    yourScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                }
                else if(computerChoice ==  3){
                    System.out.println("My answer was paper. Paper eats rock. You lose. ");
                    computerScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                }
                else {
                    System.out.println("It's a tie!");
                }
                round++;
                System.out.println("Round " + round);
            }
            else if (lvalue.equals(b)) {
                if (computerChoice == 1) {
                    System.out.println("My answer was rock. Paper eats rock. You won.");
                    yourScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                } else if (computerChoice == 2) {
                    System.out.println("My answer was scissors. Scissors cuts paper. You lost. ");
                    computerScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                } else {
                    System.out.println("It's a tie!");
                }
                round++;
                System.out.println("Round " + round);
            }
             else if(lvalue.equals(c)) {
                if (computerChoice == 1) {
                    System.out.println("My answer was rock. Rock breaks scissors. You lost.");
                    computerScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                }
                else if (computerChoice == 3) {
                    System.out.println("My answer was paper. Scissors cuts paper. You won.");
                    yourScore++;
                    System.out.println("Your score = " + yourScore + " " + "My score = " + computerScore);
                }
                else {
                    System.out.print("It's a tie!");
                }
                round++;
                System.out.println("Round " + round);
                }
             else {
                 System.out.println("You have to write rock, paper or scissors. ");
            }
            if ( yourScore == 5 || computerScore == 5 ) {

                counter = counter + 1; }

            }
        if (yourScore > computerScore) {
            System.out.println("Congrats! You won the game.");

        }
        else {
            System.out.println("Sorry, You lost the game.");
        }


            }

             }


















        












